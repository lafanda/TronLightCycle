package com.company;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
/*
Player class
does movement, collision, drawing and resets the player
*/
class TronPlayer implements ActionListener {
    int deathX, deathY;; //location where the player died

    boolean boost; //is the player boosting
    boolean text = false;
    private Timer boostTimer = new Timer(1000, this);; //how long the boost will last
    static boolean tempLife = true;

    static int vx,vy = -5; //velocityX and velocity y
    public static int x, y; //x and y position of the head

    public int currentLevel = 1; //used to check if the level has changed
    static int boostAmount = 3; //amount of boosts
    static int playerLives = 3; //lives you have

    private final int[] controls; //player 1 controls
    public static boolean boostHold = false; //making sure your not holding down the boost
    public  boolean playerLife = true; //if the player is alive

    Font font = new Font("Comic Sans MS",Font.BOLD, 20); //font
    public static final int UP = 0, LEFT = 1, DOWN = 2, RIGHT = 3, SPACE = 4; //directions with the number corresponding to the index of controls
    static public ArrayList<ArrayList<Integer>> positionsPerPlayer = new ArrayList<>(); //array list of all the positions
    private static int Direction = UP; //setting the default direction to up;

    private Timer textTimer = new Timer(800,this);

    //------------------------------------------------------------------------------------------------
    //constructor
    public TronPlayer(int xx, int yy, int[] con) {
        x = xx; //setting the start location and controls
        y = yy;
        controls = con;
    }
    //------------------------------------------------------------------------------------------------
    //resets the player
    public  void reset() {
        boost = false;
        x = 290; //resets the  x,y and vx, vy
        y = 670;
        vx = 5;
        vy = -5;
        tempLife = true;
        playerLife = true;
        TronPanel.positions.clear(); //resets the location lists
        positionsPerPlayer.clear();
        Direction = UP;   //direction and boost
        boostAmount = 3;
        if (TronPanel.level <= 3) {
            Ai.amountOfEnemies = 1;//sets the amount of enemies
        }
        if (TronPanel.level >=4) {
            Ai.amountOfEnemies = 2;
        }
        if (TronPanel.level >=7) {
            Ai.amountOfEnemies = 3;
        }
        if (playerLives ==0){ //if the player loses all his lives re start the game
            TronPanel.points = 1000;
            Ai.tempLevel = 1;
            TronPanel.level = 1;
            playerLives = 3;
            Ai.amountOfEnemies = 1;
            }
        }

    //------------------------------------------------------------------------------------------------
    //sets the direction checks boost and then calls move
    public void moveDirection(boolean[] keys, ArrayList<ArrayList<Integer>> positions) {
        if(!keys[controls[SPACE]]){ //if you are not holding space you can boost
            boostHold = false;
        }

        if (keys[controls[SPACE]] && !boostHold && boostAmount >= 1) { // if you press space boost and start the timer for 1 second
            boostTimer.stop();
            boostTimer.start();
            boost = true;
            boostHold = true;

        }
        if (keys[controls[UP]] && Direction !=DOWN) { //change vx and vy depending on what you click, and you cant move backwords
            Direction = UP;
            vy =-5;
        }
        if (keys[controls[DOWN]] && Direction != UP) {
            Direction = DOWN;
            vy = 5;
        }
        if (keys[controls[RIGHT]] && Direction != LEFT) {
            Direction = RIGHT;
            vx = 5;
        }
        if (keys[controls[LEFT]] && Direction != RIGHT) {
            Direction = LEFT;
            vx =-5;
        }

        move(Direction, positions); // call move with new direction and position list
    }
    //------------------------------------------------------------------------------------------------
    //change the x y and add them to the arrays
    public void move(int direction, ArrayList<ArrayList<Integer>> positions) {
        ArrayList<Integer> pos1 = new ArrayList<>(); //temporary array list
        pos1.add(x); //add the x y and type too the temporary array list
        pos1.add(y);
        pos1.add(1);
        positions.add(pos1); //add the temporary array list to the 2d array list of all locations
        positionsPerPlayer.add(pos1); //add the temporary array list to the 2d array list for the player

        if (direction == UP && y > 100 ||direction == DOWN && y < 680) { //move the player as long as its not our of bounds
            y += vy;
        }
        if (direction == RIGHT && x < 580 ||direction == LEFT && x > 0) {
            x += vx;
        }

        ArrayList<Integer> pos2 = new ArrayList<>(); //add the positions again so that when you boost theres no gap in your path when you boost
        pos2.add(x);
        pos2.add(y);
        pos2.add(1);
        positions.add(pos2);
        positionsPerPlayer.add(pos2);


        if (boost) {
            for (int i = 0; i < positions.size() - (Ai.amountofPlayers)*2; i++) { //check collision again while boosting so you dont faze through people
                if (positions.get(i).get(0) == x && positions.get(i).get(1) == y) {
                    deathX = x;
                    deathY = y;
                    playerLives-=1;
                    textTimer.start();
                    playerLife = false;
                    text = true;
                    TronPanel.points-=500;
                    break;
                }

            }
            for (ArrayList<Integer> position : positions) {
                if (position.get(2) != 1 && playerLife) {
                    if (position.get(0) == x && position.get(1) == y) {
                        deathX = x; //set the death location
                        deathY = y;
                        playerLives -= 1; //remove a life
                        textTimer.start();
                        text = true;
                        TronPanel.points -= 500;
                        playerLife = false; //kill the player
                        break;
                    }
                }
            }
            if (direction == UP && y > 100 || direction == DOWN && y < 680) { //move again if boosting (twice as fast)
                y += vy;
            }
            if (direction == RIGHT && x < 580 || direction ==LEFT  && x > 0) {
                x += vx;
            }
        }
    }

    //------------------------------------------------------------------------------------------------
    //checks colision
    public void collision(ArrayList<ArrayList<Integer>> positions) {
        if(!tempLife && Ai.amountOfEnemies == 0){
            playerLife = false;
        }
        for (int i = 0; i < positions.size() - (Ai.amountofPlayers)*2; i++) { //iterates through the list of all the enemies positions(minus the first positions because then the would constantly collide
            if (positions.get(i).get(0) == x && positions.get(i).get(1) == y) { //if a collision is found
                deathX = x; //set the death location
                deathY = y;
                playerLives-=1; //remove a life
                textTimer.start();
                text = true;
                TronPanel.points-=500;
                playerLife = false; //kill the player
                break;
            }

        }
        for (ArrayList<Integer> position : positions) {
            if (position.get(2) != 1 && playerLife) {
                if (position.get(0) == x && position.get(1) == y) {
                    deathX = x; //set the death location
                    deathY = y;
                    playerLives -= 1; //remove a life
                    textTimer.start();
                    text = true;
                    TronPanel.points -= 500;
                    playerLife = false; //kill the player
                    break;
                }
            }
        }
    }
    //------------------------------------------------------------------------------------------------
    //draws everything for the player
    public void draw(Graphics g,Boolean boom){

        Image picBoom = new ImageIcon("boom.png").getImage(); //explosion png
        String[] CarDirections = {"U","D","L","R"}; //used to load all the car images
        Image [] player1cars = new Image [4];

        for (int i = 0; i<2; i++){ //goes from 0-1 to load the car images
            for(int k = 0 ; k < CarDirections.length; k++){ //goes through U,D,L,R to load the car images
                Image CarImage = new ImageIcon(String.format("Car%.1s%.1s.png",i,CarDirections[k])).getImage(); //loads the car
                if (i == 0){
                    player1cars[k] = CarImage; //adds the player 1 cars to its own lists
                }
                else{
                    Ai.enemy1cars[k] = CarImage; //adds the enemy cars to its list
                }
            }
        }

        for (int i = 0; i < positionsPerPlayer.size() - 2; i++) { //draws path
            g.setColor(Color.blue);
            g.fillRect(positionsPerPlayer.get(i).get(0), positionsPerPlayer.get(i).get(1), 5, 5);
        }
        if(playerLife) {

            if (Direction == UP) { //uploads the car image at the x,y. the few adjustments are so that its aligned perfectly
                g.drawImage(player1cars[0], x - 8, y - 8, null);
            }
            if (Direction == DOWN) {
                g.drawImage(player1cars[1], x - 8, y - 8, null);
            }
            if (Direction == LEFT) {
                g.drawImage(player1cars[2], x - 10, y - 8, null);
            }
            if (Direction == RIGHT) {
                g.drawImage(player1cars[3], x - 10, y - 8, null);
            }
        }
        if (TronPanel.level>0){ //prints -500 points if the player dies
            if(text){
                g.setFont(font);
                g.setColor(Color.red);
                g.drawString("POINTS - 500 ", 10, 620);
            }
        }
        if(boom) { //draws the explosion at the position of the crash
            if (Direction == UP) {
                g.drawImage(picBoom, deathX-10, deathY-5, null);
            }
            if (Direction == DOWN) {
                g.drawImage(picBoom, deathX-10, deathY-5, null);
            }
            if (Direction == LEFT) {
                g.drawImage(picBoom, deathX-10, deathY-8, null);
            }
            if (Direction == RIGHT) {
                g.drawImage(picBoom, deathX-10, deathY-8, null);
            }

        }
    }



    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if((actionEvent).getSource() == boostTimer) {
            boost = false; //turns off the boost after 1 second
            boostAmount -= 1;
            ((Timer) actionEvent.getSource()).stop();
        }
        if((actionEvent).getSource() == textTimer) {
            text = false; //stops priting the + points text
            tempLife = true; //makes the player alive
            playerLife = true;
            ((Timer) actionEvent.getSource()).stop();
        }

    }
}

