
package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

/*
Ai class
does all the same things as the player class except the move is random and the enemy dodges on its own
the boost is also random.
*/

class Ai implements ActionListener {
    Random rand = new Random(); //random import
    Font font = new Font("Comic Sans MS",Font.BOLD, 20); //font

    int speed = 5; //how much the enemy is moving by
    int collide = 0; // used to check what direction the enemy was going when he collide
    public boolean aiLife = true;//the ai is alive
    public  int time = 1; //constantly adding 1, used for the boost
    public static int tempLevel = 1; //used to check if the level changed

    public int x, y,OGx,OGy,deathX,deathY; //current x,y, original x,y, x,y of death
    public static final int UP = 0, LEFT = 2, DOWN = 1, RIGHT = 3; // directions
    public int aiDirection = DOWN; // direction the Ai is moving
    public int straight = DOWN; //the direction its going before it turned


    private Timer boostTimer = new Timer(1000, this); //sets boost for 1 second
    private Timer resetTimer = new Timer(1000, this);
    private Timer textTimer = new Timer(1000,this);

    int Timeboost = rand.nextInt(100) + 50; //when it boosts
    public boolean boost = false; //is the enemy boosting
    public boolean boostHold = false; //makes sure it doesnt boost multple times in a row
    public int aiBoostAmount = 3; //how many boosts the ai has

    int leftDist, rightDist,upDist,downDist; //how far to this direction is the wall
    public  ArrayList<ArrayList<Integer>>positionsPerPlayer = new ArrayList<>(); //the arraylist of all the each enemies locations


    public static int amountofPlayers = 2; //amount of players in the game
    public static int amountOfEnemies = 1; //amount of enemies alive

    public boolean boom = false; //is the explosion being shown
    boolean tempAiLife = true; //is the ai alive (used for boom)

    public static Image [] enemy1cars = new Image [4]; //all the car images


    //------------------------------------------------------------------------------------------------
    //constructor, sets x,y,ogx,ogy and the amount of enemies
    public Ai(int xx, int yy) {
        x = xx;
        y = yy;
        OGx = x;
        OGy = y;
        if (TronPanel.level >3){
            amountOfEnemies =2;
        }
        if (TronPanel.level >6){
            amountOfEnemies =3;
        }

    }
    //------------------------------------------------------------------------------------------------
    //resets the enemy
    public void reset() {
        boost = false;
        x = OGx; //resets the x y
        y = OGy;
        positionsPerPlayer.clear(); //clears that players list
        aiDirection = DOWN; //resets the direction
        aiBoostAmount = 3; //resets the amount of boosts
        if (amountOfEnemies == 0 && !boom) { //if all the enemies are dead
            TronPlayer.tempLife = false; //kills the player so he can be reset
            aiLife = true; //make the enemy alive
            TronPanel.boom = false; //ends the boom
            TronPanel.points += 1000; //give the player 1000 points
            TronPlayer.playerLives = 3; //gives the player all his lives back
        }
    }
    //------------------------------------------------------------------------------------------------
    //collision, checks if the head collides with anything
    public void collision( ArrayList<ArrayList<Integer>>positions,int type) {
        for (int i = 0; i < positions.size() - amountofPlayers*2; i ++) {
            if (positions.get(i).get(0) == x && positions.get(i).get(1) == y || !aiLife) {
                for (int k = 0; k < positions.size(); k ++) {  //if theres a collision remove all of that enemies positions
                    if(k<(positions.size())-1) {
                        if (positions.get(k).get(2) == type) {
                            positions.remove(k);
                            if (k < (positions.size()) ) {
                                positions.remove(k); //its removed twice because each enemy is added twice due to the boost
                            }
                        }
                    }
                 }
                deathX = x;
                deathY = y;
                TronPanel.points+=500; //if theres collision give the player 500 points
                tempAiLife = false; //turn og his templife which is used for the explosion
                boom = true; //activate the explosion
                aiLife = false; //kill the enemy
                break;
            }
        }
    }
    //------------------------------------------------------------------------------------------------
    //moves the enemy randomly and allows for dodging
    public void move(ArrayList<ArrayList<Integer>> positions,int type) {
            Timeboost = rand.nextInt(100) + 50; //when it boosts
            time++; //used for random boosts
            collide = 0;// if its 1 that means it should check UP/DOWN if its 2 check left/right
            ArrayList<Integer> pos1 = new ArrayList<>(); //temporary array list
            pos1.add(x); //adds the x y and enemy to the array and then ands this to the array of all positions and its own array
            pos1.add(y);
            pos1.add(type);
            positions.add(pos1); //(im aware i could have made the array take in an object, but by the time I realized arrays can hold objects i was already 80% done)
            positionsPerPlayer.add(pos1);
        //------------------------------------------------------------------------------------------------

            if (aiDirection == UP) { //move the enemy depending on the direction
                y -= speed;
            }
            if (aiDirection == DOWN) {
                y += speed;
            }
            if (aiDirection == RIGHT) {
                x += speed;
            }
            if (aiDirection == LEFT) {
                x -= speed;
            }
        //------------------------------------------------------------------------------------------------


        ArrayList<Integer>pos2 = new ArrayList<>(); //add them again, same reasoning as for the player
        pos2.add(x);
        pos2.add(y);
        pos2.add(type);
        positions.add(pos2);
        positionsPerPlayer.add(pos2);
        //------------------------------------------------------------------------------------------------


            if(boost) {
                for (int i = 0; i < positions.size() - amountofPlayers*2; i ++) { //if boosting check collision and move again(same as for player)
                    if (positions.get(i).get(0) == x && positions.get(i).get(1) == y || !aiLife) {
                        for (int k = 0; k < positions.size(); k++) {  //if theres a collision remove all of that enemies positions
                            if (positions.get(k).get(2) == type) {
                            positions.remove(k);
                                if (k < (positions.size() - 1)) {
                                    positions.remove(k); //its removed twice because each enemy is added twice due to the boost
                                }
                            }
                        }
                        deathX = x;
                        deathY = y;
                        TronPanel.points+=500; //if theres collision give the player 500 points
                        tempAiLife = false; //turn off his templife which is used for the explosion
                        boom = true; //activate the explosion
                        aiLife = false; //kill the enemy
                        break;
                    }
                }
                if (aiDirection == UP) { //moves enemy if boosting
                    y -= speed;
                }
                if (aiDirection == DOWN) {
                    y += speed;
                }
                if (aiDirection == RIGHT) {
                    x += speed;
                }
                if (aiDirection == LEFT) {
                    x -= speed;
                }
        }
        //------------------------------------------------------------------------------------------------
        if (y <= 100 || y >= 680 || x >= 580 || x <= 0) { //kill the enemy if he goes out of bounds
            aiLife = false;
        }
        //------------------------------------------------------------------------------------------------

        if (time % Timeboost != 0) { //make time boost false unless the random time is met
            boostHold = false;
        }
        if (time % Timeboost == 0 && !boostHold && aiBoostAmount >= 1) {
            boost = true;
            boostTimer.start();
            boostHold = true;

        }
        //------------------------------------------------------------------------------------------------

        int turnTime = rand.nextInt(200)+100; //randomly turn
        if (time%turnTime == 0){
            if(aiDirection == LEFT|| aiDirection == RIGHT) {
                aiDirection = rand.nextInt(2); //the random numbers are to make sure he doesnt turn into himself
            }
            if(aiDirection == UP|| aiDirection == DOWN) {
                aiDirection = rand.nextInt(2)+2;
            }

        }
        //------------------------------------------------------------------------------------------------
        for (int i = 0; i < positions.size() - amountofPlayers * 2; i++) {
            for (int k = 0; k < 50; k++) {
                if (aiDirection == UP) {
                    if ((positions.get(i).get(0) == x && positions.get(i).get(1) == y - k) || y - 50 <= 100) { //checks 50 pixels ahead of it to check if there is going to be a collision
                        collide = 1;
                        break; //when it finds a future collision break
                    }
                }
                if (aiDirection == DOWN) {
                    if ((positions.get(i).get(1) == y + k && positions.get(i).get(0) == x) || y + 50 >= 680) {
                        collide = 1;
                        break;
                    }
                }
                if (aiDirection == LEFT) {
                    if ((positions.get(i).get(0) == x - k && positions.get(i).get(1) == y) || x - 50 <= 0) {
                        collide = 2;
                        break;
                    }
                }

                if (aiDirection == RIGHT) {
                    if ((positions.get(i).get(0) == x + k && positions.get(i).get(1) == y) || x + 50 >= 580) {
                        collide = 2;
                        break;
                    }
                }
            }
        }

        for (int i = 0; i < positions.size() - amountofPlayers * 2; i++) {
            if (collide == 1) { //if the collision is going to happen on the y axis
                for (rightDist = 0; rightDist < 50; rightDist++) { //check if theres anything on its left
                    if ((positions.get(i).get(0) == x + rightDist && positions.get(i).get(1) == y) || x + 50 >= 580) {
                        break;
                    }
                }
                for (leftDist = 0; leftDist < 50; leftDist++) { //checks if theres anything on its right
                    if ((positions.get(i).get(0) == x - leftDist && positions.get(i).get(1) == y) || x - 50 <= 0) {
                        break;
                    }
                }
                if (rightDist > leftDist || leftDist > rightDist) { //dont keep iterating through the list if theres already a match
                    break;
                }
            }

            if (collide == 2) {
                for (upDist = 0; upDist < 50; upDist++) { //same but for x axis
                    if ((positions.get(i).get(0) == x && positions.get(i).get(1) == y - upDist) || y - 50 <= 100) {
                        break;
                    }
                }
                for (downDist = 0; downDist < 50; downDist++) {
                    if ((positions.get(i).get(0) == x && positions.get(i).get(1) == y + downDist) || y + 50 >= 680) {
                        break;
                    }
                }
                if (upDist>downDist || downDist > upDist){
                    break;
                }
            }
        }
        //------------------------------------------------------------------------------------------------
        straight = aiDirection; //setting the current direction


        if (collide == 2) {
            if (upDist < 5 && downDist <5){ //if it will die no matter where it turns, keep going straight
                aiDirection = straight;
            }
            else if (upDist > downDist) { //if theres more room up, go up
                aiDirection = UP;
            }
            else if (downDist > upDist) { //if theres more room down go down
                aiDirection = DOWN;
            }
            else if (downDist == 50 && upDist == 50) { //if theres nothing on both sides, move randomly
                aiDirection= rand.nextInt(2);
            }
        }

        if (collide == 1) { //same but for y axis
             if (leftDist < 5 && rightDist < 5) {
                aiDirection = straight;
            }

             else if (rightDist > leftDist) {
                aiDirection = RIGHT;
            }
             else if (leftDist > rightDist) {
                aiDirection = LEFT;
            }
            else if (leftDist == 50 && rightDist == 50) {
                aiDirection = rand.nextInt(2) + 2;
            }

        }

    }

    //------------------------------------------------------------------------------------------------
    //draws the car, paths and points

    public void draw(Graphics g, Color color) {


        if(TronPanel.level == tempLevel +1 && TronPanel.level>0) { // draws the points +1000 when u go to the next level
            textTimer.start();
            g.setFont(font);
            g.setColor(Color.GREEN);
            g.drawString("level + 1", 10,600);
            g.drawString("POINTS + 1000 ", 10,620);


        }
        //------------------------------------------------------------------------------------------------

        for (int i = 0; i < positionsPerPlayer.size() - 2; i++) { //draws path
            g.setColor(color);
            g.fillRect(positionsPerPlayer.get(i).get(0), positionsPerPlayer.get(i).get(1), 5, 5);

        }
        //------------------------------------------------------------------------------------------------
        //draws the car at the x, y
        if(aiLife && TronPlayer.tempLife) {
            if (aiDirection == UP) {
                g.drawImage(enemy1cars[0], x - 8, y - 5, null);
            }
            if (aiDirection == DOWN) {
                g.drawImage(enemy1cars[1], x - 8, y - 5, null);
            }
            if (aiDirection == LEFT) {
                g.drawImage(enemy1cars[2], x - 10, y - 8, null);
            }
            if (aiDirection == RIGHT) {
                g.drawImage(enemy1cars[3], x - 10, y - 8, null);
            }
        }
        if(!tempAiLife && boom) { //if the enemy dies draw the amount of points added
            Image picBoom = new ImageIcon("boom.png").getImage(); //loads boom
            if (aiDirection == UP) { //draws the boom at the place of death for a few seconds.
                g.drawImage(picBoom, deathX-8, deathY-8, null);
            }
            if (aiDirection == DOWN) {
                g.drawImage(picBoom, deathX-8, deathY-8, null);
            }
            if (aiDirection == LEFT) {
                g.drawImage(picBoom, deathX-10, deathY-8, null);
            }
            if (aiDirection == RIGHT) {
                g.drawImage(picBoom, deathX-10, deathY-8, null);
            }
            g.setFont(font);
            g.setColor(Color.GREEN);
            g.drawString("POINTS + 500 ", 10,600);
            resetTimer.start();


        }

    }

    //------------------------------------------------------------------------------------------------

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if(actionEvent.getSource() == boostTimer) { //boosts for 1 second
            Timeboost = rand.nextInt(100) + 100;
            aiBoostAmount -=1;
            boost = false;
            ((Timer) actionEvent.getSource()).stop();
            speed = 5;
        }
        if(actionEvent.getSource() == resetTimer){ //keeps boom up for 1/2 a second
            boom = false;
            tempAiLife = true; //resets the life
            amountOfEnemies--; //remove 1 enemy
            if (amountOfEnemies == 0){
                TronPanel.level ++; //incraese the level
            }
            reset();
            ((Timer) actionEvent.getSource()).stop();
        }
        if(actionEvent.getSource() == textTimer){ //keeps text up for 1/2 a second
            tempLevel++;
            ((Timer) actionEvent.getSource()).stop();

        }

    }
}




