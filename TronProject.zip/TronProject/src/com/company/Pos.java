package com.company;

public class Pos {
    private int x;
    private int y;
    private Ai ai;

    public void Pos(int x, int y, Ai ai){
        this.x = x;
        this.y = y;
        this.ai = ai;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Ai getAi() {
        return ai;
    }
}
