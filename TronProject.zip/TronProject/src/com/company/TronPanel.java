
package com.company;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
/*
Main Class
creates the objects for the player and enemies
creates the intro and ending screen. also calls all the main functions
for the player/enemies
*/
class TronPanel extends JPanel implements KeyListener, ActionListener {
    private boolean[] keys; //the key being pressed
    private Timer myTimer; //frame rate timer
    int highScore = 0;

    private TronPlayer player1; //player object
    private Ai ai1, ai2, ai3; //enemy objects

    public static int level = 0; //level of game
    public static int points =0; //starting points
    public static boolean boom = false; //if the explosion png is being displayed

    Font font = new Font("Comic Sans MS",Font.BOLD, 25); //fonts
    Font font2 = new Font("Comic Sans MS",Font.BOLD, 35);

    public static ArrayList<ArrayList<Integer>>positions = new ArrayList<>(); //positions of all objects

//constructor
    public TronPanel() {
        keys = new boolean[KeyEvent.KEY_LAST +1];
        myTimer = new Timer(50, this);
        int[] p1Controls = {KeyEvent.VK_W, KeyEvent.VK_A, KeyEvent.VK_S, KeyEvent.VK_D,KeyEvent.VK_SPACE}; //adding controls
        //-----------------------------------------------------------------------------------------------
        //creating objects
        player1 = new TronPlayer(290, 670, p1Controls); //setting the starting location for all the objects
        ai1 = new Ai(290, 110);
        ai2 = new Ai(400, 110);
        ai3 = new Ai(190, 110);

        //------------------------------------------------------------------------------------------------
        //making screen and adding keyListener
        setPreferredSize(new Dimension(580, 680));
        addKeyListener(this);

    }

    @Override
    public void addNotify() {
        super.addNotify();
        setFocusable(true);
        requestFocus();
        myTimer.start();
    }

    //calls the collision move and reset and runs constantly (updates the game).
    public void updateGame() {
        Path filePath = Path.of("highScore.txt");
        if(points > highScore) {
            try {
                Files.writeString(filePath, Integer.toString(points));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //------------------------------------------------------------------------------------------------
        //as long as the level is less then 10 run the main game functions
        boom = false; // if true show explosion for player
        if (level <= 10 && level >= 1) {
            if (player1.playerLife) { //call move and collision for all the objects(if they are alive)
                player1.collision(positions);
                player1.moveDirection(keys, positions);
                if (ai1.aiLife) {
                    ai1.collision(positions,2);
                    ai1.move(positions, 2);
                }
                if (level > 3) {
                    if (ai2.aiLife) {
                        ai2.collision(positions,3);
                        ai2.move(positions, 3);
                    }

                    if (level > 6) {
                        if (ai3.aiLife) {
                            ai3.collision(positions,4);
                            ai3.move(positions, 4);
                        }
                    }
                }
            }
            //------------------------------------------------------------------------------------------------
            //if the player is dead
            if (!player1.playerLife) {
                boom = true; // make the explosion true and reset all the enemies
                ai1.reset();
                ai1.aiLife = true;
                if (level > 3) {
                    Ai.amountofPlayers = 3;
                    ai2.reset();
                    ai2.aiLife = true;
                    if (level > 6) {
                        Ai.amountofPlayers = 4;
                        ai3.reset();
                        ai3.aiLife = true;

                    }
                }
                player1.reset(); //reset the player if he dies
            }
            if (points > 0) { //constantly subtract 1 from points
                points-=1;
            }
        }
    }

    //------------------------------------------------------------------------------------------------
    @Override
    public void paint(Graphics g) {

        g.setFont(font);
        Scanner input = null;
        File file = new File("highScore.txt");
        try {
            input = new Scanner(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        highScore = input.nextInt();

        //loads all the images
        Image picStart = new ImageIcon("Start.png").getImage();
        Image picHeart = new ImageIcon("heart.png").getImage();
        Image picBoost = new ImageIcon("boost.png").getImage();
        Image picGrid = new ImageIcon("myGrid.png").getImage();
        Image picVictory = new ImageIcon("victory.jpg").getImage();

        if (level == 0){ //if your on the loading screen
            boolean gameStart = false; // the game isnt running
            g.setColor(Color.black);
            g.fillRect(0, 0, 700, 700); //making thw screen black
            g.drawImage(picStart, 28, 50, null);
            g.setColor(Color.white);
            g.drawString(Integer.toString(highScore), 290, 395);
            if(keys[KeyEvent.VK_SPACE]){ //if the user hits space start the game at level 1
                TronPlayer.boostHold = true;
                gameStart = true;
            }
            if(gameStart){
                points = 1000;
                level = 1;
            }
        }
        //------------------------------------------------------------------------------------------------
        if (level >= 1 && level <=10) { //if the game is running

            g.setColor(Color.black);
            g.fillRect(0, 0, 700, 700); //making the top black banner
            g.setColor(Color.white);
            g.drawString("POINTS: "+ Integer.toString(points), 200,55); //prints the amount of points you have
            for (int i = 0; i < TronPlayer.playerLives; i++){
                g.drawImage(picHeart, 1 + (65 *i), 30, null); //draws 3 hearts
            }
            for (int i = 0; i < TronPlayer.boostAmount; i++){
                g.drawImage(picBoost, 520 - (65 *i), 25, null); //draws 3 boosts
            }

            g.drawImage(picGrid, 0, 100, null);
            player1.draw(g,boom); //draws the paths
            ai1.draw(g, Color.orange);
            if (level > 3) {
                ai2.draw(g, Color.green);
                if (level > 6) {
                    ai3.draw(g, Color.red);
                }
            }
            g.setFont(font);
            g.setColor(Color.GREEN);
            g.drawString("level "+TronPanel.level, 270,90); //drawing out what level it is
        }


        //------------------------------------------------------------------------------------------------
        if(level == 11) { //if the game is over
            g.setColor(Color.black);
            g.fillRect(0,0,580,800); //draw a black rect over the screen
            g.drawImage(picVictory, -340, -100, null);//draw the victory image
            g.setColor(Color.white);
            g.setFont(font2);
            g.drawString("SCORE : "+ Integer.toString(points), 150,580); //draws out the final score
        }

    }

    @Override
    public void keyTyped(KeyEvent keyEvent) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()] = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()] = false;

    }

    @Override
    public void actionPerformed(ActionEvent evt) {
        updateGame();
        repaint();   // Asks the JVM to indirectly call paint
    }
}