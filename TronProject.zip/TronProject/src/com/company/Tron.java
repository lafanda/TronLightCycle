/*
Yazan Hailat
TronProject.iml
TronLightCycles. A one player game where the user can drive around in his car while trying to avoid other enemy
trails. the enemies have basic movement patterns where they either randomly turn or if they are approaching a wall or
another persons trail they turn to avoid it. Both the player and the enemy have 3 boosts, boost makes the player twice as fast.
the player has 3 lives to finish each round, if they lose all 3 lives the game resets. the game is 10 levels long
and by the end the player is given a score based on how long it took them to beat the game.
*/
package com.company;
import javax.swing.*;
class Tron extends JFrame {
    public Tron() {
        super("Move the Box");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TronPanel game = new TronPanel();
        add(game);
        pack();
        setVisible(true);
    }

    public static void main(String[] arguments) {
        com.company.Tron frame = new com.company.Tron();
    }
}

